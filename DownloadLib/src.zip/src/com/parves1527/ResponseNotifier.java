package com.parves1527;

import com.parves1527.download.info.DownloadDetail;

public interface ResponseNotifier
{
    void notify(DownloadDetail downloadDetail);
}
