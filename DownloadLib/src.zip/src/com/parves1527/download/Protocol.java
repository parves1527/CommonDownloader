package com.parves1527.download;

public enum Protocol
{
    http, https, ftp, sftp
}
