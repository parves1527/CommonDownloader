package com.parves1527.download.info;

public enum DownloadStatus
{
    requested, ongoing, pending, completed, failed
}
