package com.parves1527.download;

public class Main
{
    public static void main(String[] args)
    {
        ConsoleClient client = new ConsoleClient();
        client.start();
        
//        http://example.com/index.html
//        ftp://speedtest.tele2.net/1KB.zip anonymous password
//        sftp://test.rebex.net/readme.txt demo password
//        quit
    }          
}
